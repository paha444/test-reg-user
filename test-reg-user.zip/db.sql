-- phpMyAdmin SQL Dump
-- version 4.6.5.2
-- https://www.phpmyadmin.net/
--
-- Хост: 127.0.0.1:3306
-- Время создания: Дек 10 2019 г., 12:44
-- Версия сервера: 5.5.53
-- Версия PHP: 5.6.29

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `test-reg-user`
--
CREATE DATABASE IF NOT EXISTS `test-reg-user` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `test-reg-user`;

-- --------------------------------------------------------

--
-- Структура таблицы `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `login` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `params` text NOT NULL,
  `hash` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `phone` varchar(255) NOT NULL,
  `dop_info` text NOT NULL,
  `image` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;

--
-- Дамп данных таблицы `users`
--

INSERT INTO `users` (`id`, `login`, `password`, `params`, `hash`, `email`, `name`, `phone`, `dop_info`, `image`) VALUES
(1, 'admin', 'e10adc3949ba59abbe56e057f20f883e', '', '', '', '', '', '', ''),
(3, 'admin2', '123456', '', '', 'mozer_pavel@mail.ru', 'Тест', '234234234', 'доп инфо', ''),
(5, 'admin3', '1c61643e42739398e9285fe2dff509ac', '', '', 'admin3@mail.ru', 'admin3', '24234', 'admin3одолдод', 'a4dab15b3acc3878d0aef27ad416e175.jpg'),
(6, 'admin4', 'ada3f83b5089378f0a4fd535c145279b', '', '', 'admin4@mail.ru', '', '', '', ''),
(7, 'admin5', '096583d306d48140661973f2985ee1ad', '', '', 'admin5@mail.ru', '', '', '', ''),
(8, 'admin6', 'd94165a0bb54cd22426f3011a05cf1da', '', '', 'admin6@gmail.com', '', '', '', '75daeaba3d40a395b1a16bd5b3b881ca.jpg'),
(9, 'user5', '61c21cb29dfd561cbc191f59c72db604', '', '', 'user5@gmail.com', 'Павел', '8(456) 464-6456', '', '640411a77ebd9c5b62e54ff44c061502.jpg'),
(10, 'user6', 'f5e77b71a09ef1ea93e511bfe7800072', '', '', 'user6@gmail.com', '', '', '', '646c397fd694f32ac14d2c04a5994846.jpg'),
(11, 'user7', '1c61643e42739398e9285fe2dff509ac', '', '', 'user7@gmail.com', 'Тест', '8(555) 555-5555', 'впвапвапавп34535', 'e10588460a504f112488409eec220ff5.jpg'),
(12, 'admin8', 'f2079ca23f904f37033a06ff9edbeaa0', '', '', 'admefin6@gmail.com', 'Иван', '', '', 'f6891165fdee517c141f38fd6a353cf3.jpg'),
(13, 'admin9', 'e7a33af9f24ec5c2f9f10c8796bc3d9d', '', '', 'admin9@gmail.com', 'Владимир', '8(444) 444-4444', '', '3d0664a2b7d212fda57017aeccb1bd4d.jpg'),
(14, 'admin10', '744ae604d0076c3832c467c0cd7887cb', '', '', 'admin10@gmail.com', 'Александр', '8(333) 333-3333', '', '512ee939e02c66b1ff43d7309a83c0fe.jpg'),
(15, 'admin11', '9280f68f32190e0ef521a7b6416bbb23', '', '', 'admin11@gmail.com', '', '', '', '68ec61f6c74dcdec53472d0ee92131b8.jpg');

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
