<?php if (!defined('TEST_SITE')) exit('No direct script access allowed.');


$this-> captcha_queshions = [
    array ("queshion" => "two + three", "answer" => 5),
    array ("queshion" => "one + two", "answer" => 3),
    array ("queshion" => "ten to three", "answer" => 7),
    array ("queshion" => "five + three", "answer" => 8)
];             




  
?>