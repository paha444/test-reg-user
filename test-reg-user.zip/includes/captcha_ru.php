<?php if (!defined('TEST_SITE')) exit('No direct script access allowed.');

$this->captcha_queshions = [
    array("queshion" => "два + три","answer"=>5),
    array("queshion" => "один + два","answer"=>3),
    array("queshion" => "десять - три","answer"=>7),
    array("queshion" => "пять + три","answer"=>8)
];






  
?>