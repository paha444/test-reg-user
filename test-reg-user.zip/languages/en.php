<?php if (!defined('TEST_SITE')) exit('No direct script access allowed.');

$this->languages = [
    "authorization" => "Login",
    "register" => "Register",
    "Name" => "Name",
    "password" => "Password",
    "password2" => "Confirm password",
    "Sign_in" => "Sign in",
    "Sign_in_reg"=>"Sign up",
    "Sign_in_bt" => "Sign in",
    "reg_bt" => "Registered",
    "Phone" => "Phone",
    "Email" => "Email",
    "dop_info_pl_txa" => "Additional Information",
    "your_image" => "Your Image",
    "login"=>"Login",
    "update_bt"=>"update date",
    "Exit"=>"Exit",
    "spam_protection"=>"Spam protection",
    "how_much_will"=>"How much will",
    "in_numbers"=>"in numbers",
    "text_1"=>"Hello %s, you can update your data.",
    "text_2" => "Data was updated successfully",
    "text_3" => "Update error",
    "text_4" => "Error",
    "text_5" => "You have successfully registered, now you can enter the site.",
    "text_6" => "Registration error",
    "text_7" => "You entered the wrong username / password",
    "text_8" => "Passwords do not match",
    "text_9" => "This email is already registered",
    "text_10" => "The mailing address is incorrect.",
    "text_11" => "This login has already been registered",
    "text_12" => "Enter spam protection.",
    "text_13" => "Invalid security code.",


];
  
    
?>